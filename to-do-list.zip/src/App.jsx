import { useState } from 'react';
import './App.css';
import FormComponent from './componets/FormComponent';
import TodoList from './componets/TodoList';

////spread operator
////array/objects distructuring

///usage: javascript immutability


///type of functions:
//-function declaration
//-function expression
//-arrow function


function App() {
  const [todos, setTodos] = useState([
    {
      task: "homework",
      isCompleted: false,
      id: Math.floor(Math.random() * 1000000000000),
    },
    {
      task: "swim",
      isCompleted: false,
      id: Math.floor(Math.random() * 1000000000000),
    },
    {
      task: "fishing",
      isCompleted: false,
      id: Math.floor(Math.random() * 1000000000000),
    },
    {
      task: "skiing",
      isCompleted: false,
      id: Math.floor(Math.random() * 1000000000000),
    }


  ]);

  const handleSubmit = (taskInput) => {
    setTodos([...todos, {
      task: taskInput,
      isCompleted: false,
      id: Math.floor(Math.random() * 1000000000000),
    }])
  }
  
  
  const handleDelete = (id) => {
    const updatedTodos = todos.filter((todo) => {
      return todo.id !== id
    });
    setTodos(updatedTodos)
  }


  const handleIsCompleted = (id) => {
    // const updatedTodos = ;
    // setTodos(updatedTodos)
  }

  return (
    <div className="App">
      <header >
        To do list
      </header>
      <FormComponent handleSubmit={handleSubmit} />
      <TodoList list={todos} handleDelete={handleDelete}/>
    </div>
  );
}

export default App;
