import React from 'react'
import "./TodoList.css"

const TodoList = ({ list, handleDelete }) => {

  return (
    <ul className="todo-list">
      {list.map((item) => (
        <li className="todo-item" key={item.id}>
          <div className="todo-title">{item.task}</div>
          <div className="todo-buttons">
            <button onClick={() => handleDelete(item.id)}>Delete</button>
            <input /* onClick={handleIsCompleted(item.id)} */ className="todo-checkbox" type="checkbox" checked={item.isCompleted} />
          </div>
        </li>
      ))}
    </ul>
  )
}

export default TodoList
